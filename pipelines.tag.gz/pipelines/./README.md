# Sample Application for AWS DevOps Course

#updated this file
